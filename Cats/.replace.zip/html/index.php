<?php
ini_set('display_startup_errors', 1);
ini_set("display_errors",1);
error_reporting(E_ALL);

?>
<html>
<head> 
        <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
	<h1>
		Cats!
	</h1>
	<p>
		Cats cats cats! If you like cats, this is the place for you! The whole purpose of this web application is to view cats! Then, if you think your cat is cute then you can upload your own! #CatThePlanet!
	</p>	
	<p>
		<a href="cats.php?id=0">Click here to see cats! </a>
	</p>
</body>
</html>


Sanitize user input!
- Should not allow ../ or // or .
- Check for valid file types. Only allow images. 
